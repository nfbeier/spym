Examples
========

.. toctree::
   :maxdepth: 2
   
   example_simple